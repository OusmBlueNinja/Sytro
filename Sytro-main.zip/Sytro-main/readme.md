# THIS IS NOW A CLICK GAME CUS IM BAD AT CODEING

# Sytro The Game


## Pre-Release Version Alpha 0.0.5 Out Now
![Logo](https://user-images.githubusercontent.com/89956790/149055893-d8024996-0196-49c8-9eaf-708248168b86.png)

![icon](https://img.shields.io/badge/Version-Alpha%20V0.0.5-brightgreen) ![icon](https://img.shields.io/badge/Build-Up%20To%20Date-succes)




[Website](https://www.thezone.repl.co)
          
[Donate](https://www.paypal.com/donate/?hosted_button_id=BSZ4GPYGCKC28)

Install librarys

```
pip install pygame
```

File Tree for V0.0.5


```
Sytro Game
├─ .vscode
│  ├─ extensions.json
│  └─ settings.json
├─ data
│  ├─ images
│  │  ├─ Logo.png
│  │  └─ Player.png
│  └─ sounds
│     └─ Main-Music.mp3
├─ main.py
├─ readme.md
├─ test
└─ __pycache__

```


<sub><sub>ⒸGigabite Studios LLC 2022 - 2024 <sub><sub>
